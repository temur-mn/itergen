"""
Batch iteration and flip proposal helpers.
"""

import numpy as np


def iter_batches(n_rows, batch_size):
    indices = np.arange(n_rows)
    batch_id = 0
    for start in range(0, n_rows, batch_size):
        yield batch_id, indices[start : start + batch_size]
        batch_id += 1


def _desired_flip_count(error, n, step_size, max_flip_frac):
    if n <= 0:
        return 0.0
    desired = abs(error) * step_size * n
    cap = max_flip_frac * n
    if cap > 0:
        desired = min(desired, cap)
    return max(0.0, desired)


def _pick_indices(rng, candidates, desired, flip_mode):
    n_candidates = candidates.size
    if n_candidates == 0 or desired <= 0:
        return np.asarray([], dtype=candidates.dtype)
    if flip_mode == "probabilistic":
        p = min(1.0, desired / n_candidates)
        mask = rng.random(n_candidates) < p
        return candidates[mask]
    base = int(desired)
    remainder = desired - base
    extra = 1 if rng.random() < remainder else 0
    n_flip = base + extra
    if n_flip == 0:
        return np.asarray([], dtype=candidates.dtype)
    return rng.choice(candidates, size=min(n_flip, n_candidates), replace=False)


def build_guided_flips(
    df,
    batch_index,
    marginal_targets,
    conditional_specs,
    step_size_marginal,
    step_size_conditional,
    max_flip_frac,
    min_group_size,
    rng,
    flip_mode="probabilistic",
    step_multipliers=None,
):
    flips = []
    batch_df = df.loc[batch_index]
    n_batch = len(batch_index)

    for col_id, target in marginal_targets.items():
        observed = (batch_df[col_id].values == 1).mean()
        error = target - observed
        if abs(error) < 1e-6:
            continue
        multiplier = step_multipliers.get(col_id, 1.0) if step_multipliers else 1.0
        desired = _desired_flip_count(
            error, n_batch, step_size_marginal * multiplier, max_flip_frac
        )
        if desired <= 0:
            continue
        if error > 0:
            candidates = np.asarray(batch_df.index[batch_df[col_id].values == 0])
            new_val = 1
        else:
            candidates = np.asarray(batch_df.index[batch_df[col_id].values == 1])
            new_val = 0
        chosen = _pick_indices(rng, candidates, desired, flip_mode)
        flips.extend([(idx, col_id, new_val) for idx in chosen])

    for col_id, specs in conditional_specs.items():
        if not specs:
            continue
        for spec in specs:
            cond_map = spec["cond"]
            mask = np.ones(n_batch, dtype=bool)
            missing = False
            for k, v in cond_map.items():
                if k not in batch_df.columns:
                    missing = True
                    break
                mask &= batch_df[k].values == v
            if missing:
                continue
            n_group = int(mask.sum())
            if n_group < min_group_size:
                continue
            observed = (batch_df[col_id].values[mask] == 1).mean()
            error = spec["true_prob"] - observed
            if abs(error) < 1e-6:
                continue
            multiplier = step_multipliers.get(col_id, 1.0) if step_multipliers else 1.0
            desired = _desired_flip_count(
                error, n_group, step_size_conditional * multiplier, max_flip_frac
            )
            if desired <= 0:
                continue
            if error > 0:
                candidates = np.asarray(
                    batch_df.index[mask & (batch_df[col_id].values == 0)]
                )
                new_val = 1
            else:
                candidates = np.asarray(
                    batch_df.index[mask & (batch_df[col_id].values == 1)]
                )
                new_val = 0
            chosen = _pick_indices(rng, candidates, desired, flip_mode)
            flips.extend([(idx, col_id, new_val) for idx in chosen])

    return flips


def build_random_flips(df, batch_index, columns, n_flips, rng):
    if not columns or n_flips <= 0:
        return []
    n_batch = len(batch_index)
    n_flips = min(n_flips, n_batch)
    rows = rng.choice(np.asarray(batch_index), size=n_flips, replace=False)
    cols = rng.choice(columns, size=n_flips, replace=True)
    flips = []
    for row, col in zip(rows, cols):
        val = df.at[row, col]
        new_val = 1 - int(bool(val))
        flips.append((row, col, new_val))
    return flips


def merge_flips(primary, secondary):
    flip_map = {(row, col): val for row, col, val in primary}
    for row, col, val in secondary:
        if (row, col) not in flip_map:
            flip_map[(row, col)] = val
    return [(row, col, val) for (row, col), val in flip_map.items()]


def apply_flips(df, flips):
    old_values = {}
    for row, col, val in flips:
        key = (row, col)
        if key not in old_values:
            old_values[key] = df.at[row, col]
        df.at[row, col] = val
    return old_values


def revert_flips(df, old_values):
    for (row, col), val in old_values.items():
        df.at[row, col] = val
