"""
Default settings and derived heuristics for the generator.
"""

DEFAULT_ROWS = 1000
DEFAULT_SEED = 47
DEFAULT_TOLERANCE = 0.012
DEFAULT_MAX_ATTEMPTS = 3

DEFAULT_LOG_LEVEL = "info"
DEFAULT_FLIP_MODE = "probabilistic"

DEFAULT_WEIGHT_MARGINAL = 1.0
DEFAULT_WEIGHT_CONDITIONAL = 0.6
DEFAULT_WEIGHT_MAX = 0.2


def derive_settings(n_rows, tolerance):
    rows = max(1, int(n_rows))
    tol = float(tolerance)

    batch_size = min(4096, max(256, rows // 8))
    step_base = max(0.05, min(0.35, tol * 10.0))
    step_marginal = step_base
    step_conditional = min(0.6, step_base * 1.5)
    max_flip_frac = max(0.05, min(0.25, tol * 8.0))
    min_group_size = max(10, min(50, rows // 40))

    proposals_per_batch = 50
    hybrid_ratio = 0.8
    random_flip_frac = max(0.005, min(0.02, tol))
    temperature_init = max(tol, 1e-3)
    temperature_decay = 0.97

    max_iters = max(20, min(150, rows // 8))
    patience = max(5, min(20, max_iters // 6))

    return {
        "batch_size": batch_size,
        "step_size_marginal": step_marginal,
        "step_size_conditional": step_conditional,
        "max_flip_frac": max_flip_frac,
        "min_group_size": min_group_size,
        "proposals_per_batch": proposals_per_batch,
        "hybrid_ratio": hybrid_ratio,
        "random_flip_frac": random_flip_frac,
        "temperature_init": temperature_init,
        "temperature_decay": temperature_decay,
        "max_iters": max_iters,
        "patience": patience,
        "flip_mode": DEFAULT_FLIP_MODE,
    }
