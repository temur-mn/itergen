"""
Entry point for generating synthetic binary data from a sample config.
"""

import yaml

from . import defaults
from .config import resolve_missing_columns, validate_config
from .generation import generate_until_valid
from .sample_configs import CONFIG_1


def main():
    config = yaml.safe_load(CONFIG_1)
    config = resolve_missing_columns(config, mode="prompt")
    warnings = validate_config(config)
    if warnings:
        print("[CONFIG WARNINGS]")
        for warning in warnings:
            print(f"  - {warning}")

    base_seed = defaults.DEFAULT_SEED
    tolerance = defaults.DEFAULT_TOLERANCE
    settings = defaults.derive_settings(defaults.DEFAULT_ROWS, tolerance)
    optimize_kwargs = {
        **settings,
        "log_level": defaults.DEFAULT_LOG_LEVEL,
        "weight_marginal": defaults.DEFAULT_WEIGHT_MARGINAL,
        "weight_conditional": defaults.DEFAULT_WEIGHT_CONDITIONAL,
        "weight_max": defaults.DEFAULT_WEIGHT_MAX,
    }

    df, eq, ok, attempts, _history, _initial_df = generate_until_valid(
        config,
        n_rows=defaults.DEFAULT_ROWS,
        base_seed=base_seed,
        max_attempts=defaults.DEFAULT_MAX_ATTEMPTS,
        tolerance=tolerance,
        optimize_kwargs=optimize_kwargs,
        log_level=defaults.DEFAULT_LOG_LEVEL,
        collect_history=False,
    )

    if eq is None or df is None:
        raise ValueError("No dataset or metrics available")
    assert eq is not None
    assert df is not None

    status = "OK" if ok else "BEST_EFFORT"
    print(
        f"[FINAL METRICS] status={status} attempts={attempts} "
        f"obj={eq['objective']:.4f} m_mean={eq['mean_marginal']:.4f} "
        f"c_mean={eq['mean_conditional']:.4f} max={eq['max_error']:.4f}"
    )

    print("\n[FINAL STATS]")
    for col in config["columns"]:
        col_id = col["column_id"]
        print(f"  {col_id}: {df[col_id].value_counts().to_dict()}")

    print("\n [DATASET IS SAVED]")
    df.to_excel("draft_1.xlsx")


if __name__ == "__main__":
    main()
