"""
Synthetic data generator package (binary generator with extension hooks).
"""
