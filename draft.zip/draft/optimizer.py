"""
Optimization loop using stochastic proposal acceptance.
"""

import math

from .adjustments import (
    apply_flips,
    build_guided_flips,
    build_random_flips,
    iter_batches,
    merge_flips,
    revert_flips,
)
from .config import build_targets
from .metrics import compute_column_errors, compute_equilibrium_metrics
from .nn_controller import PenaltyController
from .rng import RNG


def optimize(
    df,
    config,
    seed,
    tolerance,
    batch_size,
    max_iters,
    patience,
    step_size_marginal,
    step_size_conditional,
    max_flip_frac,
    min_group_size,
    proposals_per_batch,
    temperature_init,
    temperature_decay,
    hybrid_ratio,
    random_flip_frac,
    flip_mode,
    weight_marginal,
    weight_conditional,
    weight_max,
    log_level="info",
    history=None,
):
    marginal_targets, conditional_specs = build_targets(config)
    n_rows = len(df)
    column_ids = [col["column_id"] for col in config.get("columns", [])]
    target_columns = sorted(
        set(list(marginal_targets.keys()) + list(conditional_specs.keys()))
    )

    controller = PenaltyController(
        column_ids,
        seed=seed,
        tolerance=tolerance,
    )
    errors = compute_column_errors(
        df, marginal_targets, conditional_specs, min_group_size
    )
    multipliers = controller.compute_multipliers(errors)

    best_obj = float("inf")
    stall_count = 0
    prev_obj = None

    for it in range(1, max_iters + 1):
        temperature = max(
            1e-6, float(temperature_init) * (float(temperature_decay) ** (it - 1))
        )
        for batch_id, batch_idx in iter_batches(n_rows, batch_size):
            batch_index = df.index[batch_idx]
            base_obj = compute_equilibrium_metrics(
                df,
                marginal_targets,
                conditional_specs,
                min_group_size,
                weight_marginal=weight_marginal,
                weight_conditional=weight_conditional,
                weight_max=weight_max,
            )["objective"]

            best_batch_obj = None
            best_flips = None
            best_delta = None
            best_proposal_id = None
            best_guided = None
            best_flip_count = 0
            accepted = 0

            for proposal_id in range(proposals_per_batch):
                rng = RNG(RNG.derive_seed(seed, "proposal", it, batch_id, proposal_id))

                guided_flips = build_guided_flips(
                    df,
                    batch_index,
                    marginal_targets,
                    conditional_specs,
                    step_size_marginal,
                    step_size_conditional,
                    max_flip_frac,
                    min_group_size,
                    rng,
                    flip_mode=flip_mode,
                    step_multipliers=multipliers,
                )

                guided_count = len(guided_flips)
                guided = guided_count > 0
                if guided_count > 0:
                    random_count = int(
                        guided_count * (1.0 - hybrid_ratio) / max(hybrid_ratio, 1e-6)
                    )
                else:
                    random_count = max(1, int(len(batch_index) * random_flip_frac))

                random_flips = build_random_flips(
                    df, batch_index, target_columns, random_count, rng
                )
                flips = merge_flips(guided_flips, random_flips)

                if not flips:
                    continue

                old_values = apply_flips(df, flips)
                candidate_obj = compute_equilibrium_metrics(
                    df,
                    marginal_targets,
                    conditional_specs,
                    min_group_size,
                    weight_marginal=weight_marginal,
                    weight_conditional=weight_conditional,
                    weight_max=weight_max,
                )["objective"]

                delta = candidate_obj - base_obj
                accept = False
                if delta <= 0:
                    accept = True
                else:
                    prob = math.exp(-delta / temperature)
                    accept = rng.random() < prob

                revert_flips(df, old_values)

                if accept:
                    accepted += 1
                    if best_batch_obj is None or candidate_obj < best_batch_obj:
                        best_batch_obj = candidate_obj
                        best_flips = flips
                        best_delta = delta
                        best_proposal_id = proposal_id
                        best_guided = guided
                        best_flip_count = len(flips)

            if best_flips:
                apply_flips(df, best_flips)

            if log_level != "quiet":
                print(
                    f"[BATCH] it={it} batch={batch_id} temp={temperature:.4f} "
                    f"accepted={accepted}/{proposals_per_batch}"
                )
                if best_flips:
                    print(
                        f"[BEST] it={it} batch={batch_id} pid={best_proposal_id} "
                        f"guided={best_guided} flips={best_flip_count} "
                        f"delta={best_delta:.4f}"
                    )
                else:
                    print(f"[BEST] it={it} batch={batch_id} none")

        equilibrium = compute_equilibrium_metrics(
            df,
            marginal_targets,
            conditional_specs,
            min_group_size,
            weight_marginal=weight_marginal,
            weight_conditional=weight_conditional,
            weight_max=weight_max,
        )
        objective = equilibrium["objective"]

        errors = compute_column_errors(
            df, marginal_targets, conditional_specs, min_group_size
        )
        ctrl_stats = controller.update(errors)
        multipliers = controller.compute_multipliers(errors)

        if history is not None:
            history.append(
                {
                    "iteration": it,
                    "objective": objective,
                    "mean_marginal": equilibrium["mean_marginal"],
                    "mean_conditional": equilibrium["mean_conditional"],
                    "max_error": equilibrium["max_error"],
                }
            )

        if log_level != "quiet":
            print(
                f"[{it}] obj={objective:.4f} m_mean={equilibrium['mean_marginal']:.4f} "
                f"c_mean={equilibrium['mean_conditional']:.4f} max={equilibrium['max_error']:.4f}"
            )

        if objective <= tolerance and it >= 3:
            print("[CONVERGED]")
            break

        if objective < best_obj - 1e-6:
            best_obj = objective
            stall_count = 0
        else:
            stall_count += 1

        if prev_obj is not None and abs(prev_obj - objective) < 1e-6:
            stall_count += 1

        if stall_count >= patience:
            print("[PLATEAU]")
            break

        prev_obj = objective

    return df
