"""
Sample YAML configurations stored as strings.
"""

CONFIG = """
metadata:
  name: "simple_demo"
  version: "1.0"
columns:
  - column_id: "loyalty"
    values:
      true_value: 1
      false_value: 0
    distribution:
      type: "bernoulli"
      probabilities:
        true_prob: 0.35
        false_prob: 0.65

  - column_id: "discount"
    values:
      true_value: 1
      false_value: 0
    distribution:
      type: "bernoulli"
      probabilities:
        true_prob: 0.20
        false_prob: 0.80

  - column_id: "online"
    values:
      true_value: 1
      false_value: 0
    distribution:
      type: "conditional"
      depend_on: ["discount"]
      conditional_probs:
        "discount=1": { true_prob: 0.12, false_prob: 0.88 }
        "discount=0": { true_prob: 0.07, false_prob: 0.93 }

  - column_id: "return"
    values:
      true_value: 1
      false_value: 0
    distribution:
      type: "conditional"
      depend_on: ["online", "loyalty"]
      conditional_probs:
        "online=1, loyalty=1": { true_prob: 0.12, false_prob: 0.88 }
        "online=1, loyalty=0": { true_prob: 0.05, false_prob: 0.95 }
        "online=0, loyalty=1": { true_prob: 0.07, false_prob: 0.93 }
        "online=0, loyalty=0": { true_prob: 0.04, false_prob: 0.96 }
"""

CONFIG_1 = """
metadata:
  name: "simple_demo_extended"
  version: "1.1"

columns:
  - column_id: "loyalty"
    values: { true_value: 1, false_value: 0 }
    distribution:
      type: "bernoulli"
      probabilities: { true_prob: 0.35, false_prob: 0.65 }

  - column_id: "discount"
    values: { true_value: 1, false_value: 0 }
    distribution:
      type: "bernoulli"
      probabilities: { true_prob: 0.20, false_prob: 0.80 }

  - column_id: "online"
    values: { true_value: 1, false_value: 0 }
    distribution:
      type: "conditional"
      depend_on: ["discount"]
      conditional_probs:
        "discount=1": { true_prob: 0.12, false_prob: 0.88 }
        "discount=0": { true_prob: 0.07, false_prob: 0.93 }

  - column_id: "return"
    values: { true_value: 1, false_value: 0 }
    distribution:
      type: "conditional"
      depend_on: ["online", "loyalty"]
      conditional_probs:
        "online=1, loyalty=1": { true_prob: 0.12, false_prob: 0.88 }
        "online=1, loyalty=0": { true_prob: 0.05, false_prob: 0.95 }
        "online=0, loyalty=1": { true_prob: 0.07, false_prob: 0.93 }
        "online=0, loyalty=0": { true_prob: 0.04, false_prob: 0.96 }

  - column_id: "mobile_app"
    values: { true_value: 1, false_value: 0 }
    distribution:
      type: "bernoulli"
      probabilities: { true_prob: 0.45, false_prob: 0.55 }

  - column_id: "high_spend"
    values: { true_value: 1, false_value: 0 }
    distribution:
      type: "conditional"
      depend_on: ["loyalty", "discount"]
      conditional_probs:
        "loyalty=1, discount=1": { true_prob: 0.55, false_prob: 0.45 }
        "loyalty=1, discount=0": { true_prob: 0.45, false_prob: 0.55 }
        "loyalty=0, discount=1": { true_prob: 0.25, false_prob: 0.75 }
        "loyalty=0, discount=0": { true_prob: 0.15, false_prob: 0.85 }

  - column_id: "customer_support_contact"
    values: { true_value: 1, false_value: 0 }
    distribution:
      type: "conditional"
      depend_on: ["return", "high_spend", "online"]
      conditional_probs:
        "return=1, high_spend=1, online=1": { true_prob: 0.65, false_prob: 0.35 }
        "return=1, high_spend=1, online=0": { true_prob: 0.55, false_prob: 0.45 }
        "return=1, high_spend=0, online=1": { true_prob: 0.45, false_prob: 0.55 }
        "return=1, high_spend=0, online=0": { true_prob: 0.35, false_prob: 0.65 }
        "return=0, high_spend=1, online=1": { true_prob: 0.25, false_prob: 0.75 }
        "return=0, high_spend=1, online=0": { true_prob: 0.20, false_prob: 0.80 }
        "return=0, high_spend=0, online=1": { true_prob: 0.15, false_prob: 0.85 }
        "return=0, high_spend=0, online=0": { true_prob: 0.10, false_prob: 0.90 }

  - column_id: "subscription"
    values: { true_value: 1, false_value: 0 }
    distribution:
      type: "conditional"
      depend_on: ["loyalty", "mobile_app"]
      conditional_probs:
        "loyalty=1, mobile_app=1": { true_prob: 0.60, false_prob: 0.40 }
        "loyalty=1, mobile_app=0": { true_prob: 0.45, false_prob: 0.55 }
        "loyalty=0, mobile_app=1": { true_prob: 0.25, false_prob: 0.75 }
        "loyalty=0, mobile_app=0": { true_prob: 0.10, false_prob: 0.90 }

  - column_id: "promo_email"
    values: { true_value: 1, false_value: 0 }
    distribution:
      type: "conditional"
      depend_on: ["discount", "subscription"]
      conditional_probs:
        "discount=1, subscription=1": { true_prob: 0.75, false_prob: 0.25 }
        "discount=1, subscription=0": { true_prob: 0.55, false_prob: 0.45 }
        "discount=0, subscription=1": { true_prob: 0.35, false_prob: 0.65 }
        "discount=0, subscription=0": { true_prob: 0.15, false_prob: 0.85 }

  - column_id: "churn_risk"
    values: { true_value: 1, false_value: 0 }
    distribution:
      type: "conditional"
      depend_on:
        ["loyalty", "return", "customer_support_contact", "subscription", "high_spend"]
      conditional_probs:
        "loyalty=0, return=1, customer_support_contact=1, subscription=0, high_spend=0":
          { true_prob: 0.85, false_prob: 0.15 }
        "loyalty=0, return=1, customer_support_contact=0, subscription=0, high_spend=0":
          { true_prob: 0.70, false_prob: 0.30 }
        "loyalty=1, return=1, customer_support_contact=1, subscription=1, high_spend=1":
          { true_prob: 0.25, false_prob: 0.75 }
        "loyalty=1, return=0, customer_support_contact=0, subscription=1, high_spend=1":
          { true_prob: 0.10, false_prob: 0.90 }
        "loyalty=1, return=0, customer_support_contact=0, subscription=0, high_spend=0":
          { true_prob: 0.20, false_prob: 0.80 }
"""
