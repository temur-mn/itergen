"""
Generation loop that retries until equilibrium rules are satisfied.
"""

from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from .config import build_targets
from .initial import generate_initial
from .metrics import (
    check_equilibrium_rules,
    compute_equilibrium_metrics,
    default_equilibrium_rules,
)
from .optimizer import optimize
from .rng import RNG


def _print_stats(df, columns, label):
    print(label)
    for col in columns:
        col_id = col["column_id"]
        print(f"  {col_id}: {df[col_id].value_counts().to_dict()}")


def generate_until_valid(
    config,
    n_rows,
    base_seed,
    max_attempts=None,
    tolerance=0.02,
    rules=None,
    optimize_kwargs=None,
    log_level="info",
    collect_history=False,
) -> Tuple[
    Optional[pd.DataFrame],
    Optional[Dict[str, Any]],
    bool,
    int,
    Optional[List[Dict[str, Any]]],
    Optional[pd.DataFrame],
]:
    if optimize_kwargs is None:
        optimize_kwargs = {}
    if rules is None:
        rules = default_equilibrium_rules(tolerance)

    min_group_size = optimize_kwargs.get("min_group_size", 25)
    weight_marginal = optimize_kwargs.get("weight_marginal", 1.0)
    weight_conditional = optimize_kwargs.get("weight_conditional", 0.6)
    weight_max = optimize_kwargs.get("weight_max", 0.2)

    marginal_targets, conditional_specs = build_targets(config)
    best_df = None
    best_metrics = None
    best_history = None
    best_initial = None

    attempt = 0
    while True:
        if max_attempts is not None and attempt >= max_attempts:
            break
        attempt_seed = RNG.derive_seed(base_seed, "attempt", attempt)
        if log_level != "quiet":
            total = max_attempts if max_attempts is not None else "∞"
            print(f"[ATTEMPT {attempt + 1}/{total}] seed={attempt_seed}")

        initial_df = generate_initial(n_rows, config, seed=attempt_seed)
        df = initial_df.copy()
        if log_level != "quiet":
            _print_stats(df, config["columns"], "[INITIAL STATS]")

        history = [] if collect_history else None

        df = optimize(
            df,
            config,
            seed=attempt_seed,
            tolerance=tolerance,
            history=history,
            **optimize_kwargs,
        )

        metrics = compute_equilibrium_metrics(
            df,
            marginal_targets,
            conditional_specs,
            min_group_size=min_group_size,
            weight_marginal=weight_marginal,
            weight_conditional=weight_conditional,
            weight_max=weight_max,
        )

        ok, violations = check_equilibrium_rules(metrics, rules)
        if ok:
            return df, metrics, True, attempt + 1, history, initial_df

        if best_metrics is None or metrics["objective"] < best_metrics["objective"]:
            best_df = df
            best_metrics = metrics
            best_history = history
            best_initial = initial_df

        if log_level != "quiet":
            details = ", ".join(violations) if violations else "no violations listed"
            print(f"[RETRY] rules_not_met={details}")

        attempt += 1

    return best_df, best_metrics, False, attempt, best_history, best_initial
