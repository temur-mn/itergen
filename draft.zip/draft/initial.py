"""
Initial binary data generation.
"""

import numpy as np
import pandas as pd

from .config import order_columns_by_dependency, parse_condition
from .rng import RNG


def estimate_initial_prob(dist):
    if dist["type"] == "bernoulli":
        return float(dist["probabilities"]["true_prob"])
    cond_probs = dist.get("conditional_probs", {})
    if not isinstance(cond_probs, dict) or not cond_probs:
        return 0.5
    values = []
    for probs in cond_probs.values():
        if not isinstance(probs, dict):
            continue
        value = probs.get("true_prob")
        if isinstance(value, (int, float)):
            values.append(float(value))
    return float(np.mean(values)) if values else 0.5


def generate_initial(n_rows, config, seed=42):
    data = {}
    ordered_columns = order_columns_by_dependency(config)
    for col in ordered_columns:
        col_id = col["column_id"]
        dist = col["distribution"]
        # Binary init uses the "init" namespace; add new types with distinct namespaces.
        rng = RNG(RNG.derive_seed(seed, "init", col_id))
        if dist["type"] == "bernoulli":
            p = estimate_initial_prob(dist)
            p = max(0.0, min(1.0, p))
            data[col_id] = np.asarray(rng.random(n_rows) < p, dtype=int)
            continue

        depend_on = dist.get("depend_on", [])
        cond_probs = dist.get("conditional_probs", {})
        bias_weight = dist.get("bias_weight", 1.0)
        try:
            bias_weight = float(bias_weight)
        except (TypeError, ValueError):
            bias_weight = 1.0
        bias_weight = max(0.0, min(1.0, bias_weight))

        specs = []
        if isinstance(cond_probs, dict):
            for cond_key, probs in cond_probs.items():
                try:
                    cond_map = parse_condition(cond_key)
                except ValueError:
                    continue
                if not isinstance(probs, dict) or probs.get("true_prob") is None:
                    continue
                specs.append(
                    {
                        "cond": cond_map,
                        "true_prob": float(probs["true_prob"]),
                    }
                )
        specs.sort(key=lambda s: sorted(s["cond"].items()))

        fallback_p = estimate_initial_prob(dist)
        fallback_p = max(0.0, min(1.0, fallback_p))
        values = np.zeros(n_rows, dtype=int)
        assigned = np.zeros(n_rows, dtype=bool)

        for spec in specs:
            mask = np.ones(n_rows, dtype=bool)
            missing_parent = False
            for dep in depend_on:
                if dep not in data:
                    missing_parent = True
                    break
            if missing_parent:
                continue
            for k, v in spec["cond"].items():
                if k not in data:
                    missing_parent = True
                    break
                mask &= data[k] == v
            if missing_parent:
                continue
            if not mask.any():
                continue
            target_p = spec["true_prob"]
            effective_p = bias_weight * target_p + (1.0 - bias_weight) * fallback_p
            draw = rng.random(int(mask.sum())) < effective_p
            values[mask] = np.asarray(draw, dtype=int)
            assigned |= mask

        if (~assigned).any():
            draw = rng.random(int((~assigned).sum())) < fallback_p
            values[~assigned] = np.asarray(draw, dtype=int)

        data[col_id] = values
    return pd.DataFrame(data)
