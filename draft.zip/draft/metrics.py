"""
Metric calculations for marginal and conditional errors.
"""

import numpy as np


def _conditional_marginal_target(df, col_id, specs, min_group_size):
    if not specs:
        return None, None, 0.0
    union_mask = np.zeros(len(df), dtype=bool)
    total_weight = 0
    weighted_sum = 0.0
    for spec in specs:
        cond_map = spec["cond"]
        mask = np.ones(len(df), dtype=bool)
        missing = False
        for k, v in cond_map.items():
            if k not in df.columns:
                missing = True
                break
            mask &= df[k].values == v
        if missing:
            continue
        n_group = int(mask.sum())
        if n_group < min_group_size:
            continue
        union_mask |= mask
        total_weight += n_group
        weighted_sum += n_group * float(spec["true_prob"])

    if total_weight == 0:
        return None, None, 0.0

    target = weighted_sum / total_weight
    observed = (df[col_id].values[union_mask] == 1).mean()
    coverage = float(union_mask.mean())
    return target, observed, coverage


def collect_marginal_errors(df, marginal_targets, conditional_specs, min_group_size):
    rows = []
    for col_id, target in marginal_targets.items():
        observed = (df[col_id].values == 1).mean()
        err = abs(observed - target)
        rows.append((col_id, err, observed, target, 1.0))

    for col_id, specs in conditional_specs.items():
        if not specs:
            continue
        target, observed, coverage = _conditional_marginal_target(
            df, col_id, specs, min_group_size
        )
        if target is None or observed is None:
            continue
        target = float(target)
        observed = float(observed)
        err = abs(observed - target)
        rows.append((col_id, err, observed, target, coverage))

    return rows


def compute_column_errors(df, marginal_targets, conditional_specs, min_group_size):
    errors = {}

    for col_id, target in marginal_targets.items():
        observed = (df[col_id].values == 1).mean()
        err = abs(observed - target)
        errors[col_id] = {"m": err, "c": 0.0}

    for col_id, specs in conditional_specs.items():
        if not specs:
            continue
        group_errors = []
        for spec in specs:
            cond_map = spec["cond"]
            mask = np.ones(len(df), dtype=bool)
            missing = False
            for k, v in cond_map.items():
                if k not in df.columns:
                    missing = True
                    break
                mask &= df[k].values == v
            if missing:
                continue
            n_group = int(mask.sum())
            if n_group < min_group_size:
                continue
            observed = (df[col_id].values[mask] == 1).mean()
            group_errors.append(abs(observed - spec["true_prob"]))

        mean_err = float(np.mean(group_errors)) if group_errors else 0.0
        if col_id in errors:
            errors[col_id]["c"] = mean_err
        else:
            errors[col_id] = {"m": 0.0, "c": mean_err}

    return errors


def compute_equilibrium_metrics(
    df,
    marginal_targets,
    conditional_specs,
    min_group_size,
    weight_marginal=1.0,
    weight_conditional=0.6,
    weight_max=0.2,
):
    """
    Overall deviation between observed and target rates is below a chosen margin.
    """

    marginal_rows = collect_marginal_errors(
        df, marginal_targets, conditional_specs, min_group_size
    )
    marginal_errors = [row[1] for row in marginal_rows]
    mean_marginal = float(np.mean(marginal_errors)) if marginal_errors else 0.0
    cond_errors = []
    for col_id, specs in conditional_specs.items():
        if not specs:
            continue
        for spec in specs:
            cond_map = spec["cond"]
            mask = np.ones(len(df), dtype=bool)
            missing = False
            for k, v in cond_map.items():
                if k not in df.columns:
                    missing = True
                    break
                mask &= df[k].values == v
            if missing:
                continue
            n_group = int(mask.sum())
            if n_group < min_group_size:
                continue
            observed = (df[col_id].values[mask] == 1).mean()
            err = abs(observed - spec["true_prob"])
            cond_errors.append(err)

    mean_cond = float(np.mean(cond_errors)) if cond_errors else 0.0

    combined = marginal_errors + cond_errors
    max_error = max(combined) if combined else 0.0

    objective = (
        weight_marginal * mean_marginal
        + weight_conditional * mean_cond
        + weight_max * max_error
    )

    return {
        "objective": objective,
        "mean_marginal": mean_marginal,
        "mean_conditional": mean_cond,
        "max_error": max_error,
    }


def default_equilibrium_rules(tolerance):
    base = float(tolerance)
    return {
        "objective_max": base,
        "max_error_max": base * 2.0,
    }


def check_equilibrium_rules(metrics, rules):
    violations = []

    def check_max(key, rule_key, label):
        limit = rules.get(rule_key)
        if limit is None:
            return
        if metrics.get(key, 0.0) > float(limit):
            violations.append(f"{label}>{limit}")

    check_max("objective", "objective_max", "objective")
    check_max("max_error", "max_error_max", "max_error")
    return len(violations) == 0, violations
