"""
Configuration parsing, validation, and target extraction.
"""

import itertools
import sys


def parse_condition(key):
    if key is None:
        raise ValueError("Condition key is None")
    text = str(key).strip()
    if not text:
        raise ValueError("Condition key is empty")
    result = {}
    for part in text.split(","):
        if "=" not in part:
            raise ValueError(f"Invalid condition part: '{part}'")
        k, v = part.strip().split("=", 1)
        k = k.strip()
        v = v.strip()
        if not k or not v:
            raise ValueError(f"Invalid condition part: '{part}'")
        try:
            result[k] = int(v)
        except ValueError as exc:
            raise ValueError(f"Non-integer condition value: '{part}'") from exc
    return result


def canonical_condition_key(cond_map, order=None):
    if order is None:
        keys = sorted(cond_map.keys())
    else:
        keys = [k for k in order if k in cond_map]
        extras = [k for k in cond_map.keys() if k not in keys]
        if extras:
            keys.extend(sorted(extras))
    return ", ".join(f"{k}={cond_map[k]}" for k in keys)


def validate_config(config, strict=False):
    warnings = []
    errors = []

    columns = config.get("columns")
    if not isinstance(columns, list):
        raise ValueError("Config must include a 'columns' list")

    column_ids = [col.get("column_id") for col in columns if col.get("column_id")]
    duplicates = sorted({x for x in column_ids if column_ids.count(x) > 1})
    if duplicates:
        errors.append(f"Duplicate column_id values: {duplicates}")

    column_set = set(column_ids)

    for col in columns:
        col_id = col.get("column_id")
        if not col_id:
            errors.append("Column missing 'column_id'")
            continue

        dist = col.get("distribution")
        if not isinstance(dist, dict):
            errors.append(f"Column '{col_id}' missing distribution")
            continue

        dist_type = dist.get("type")
        if dist_type not in ("bernoulli", "conditional"):
            errors.append(
                f"Column '{col_id}' has unsupported distribution type '{dist_type}'"
            )
            continue

        if dist_type == "bernoulli":
            probs = dist.get("probabilities", {})
            tp = probs.get("true_prob")
            fp = probs.get("false_prob")
            if tp is None or fp is None:
                errors.append(f"Column '{col_id}' missing bernoulli probabilities")
            elif abs(tp + fp - 1.0) > 1e-6:
                warnings.append(f"Column '{col_id}' probabilities do not sum to 1")
        else:
            depend_on = dist.get("depend_on", [])
            if not isinstance(depend_on, list) or not depend_on:
                warnings.append(
                    f"Column '{col_id}' conditional distribution missing depend_on"
                )
                depend_on = []

            bias_weight = dist.get("bias_weight")
            if bias_weight is not None:
                try:
                    bias_weight = float(bias_weight)
                    if not 0.0 <= bias_weight <= 1.0:
                        warnings.append(
                            f"Column '{col_id}' bias_weight should be between 0 and 1"
                        )
                except (TypeError, ValueError):
                    warnings.append(
                        f"Column '{col_id}' bias_weight should be a number between 0 and 1"
                    )

            for dep in depend_on:
                if dep not in column_set:
                    warnings.append(
                        f"Column '{col_id}' depends on unknown column '{dep}'"
                    )

            cond_probs = dist.get("conditional_probs", {})
            if not isinstance(cond_probs, dict) or not cond_probs:
                warnings.append(f"Column '{col_id}' conditional_probs is empty")
                cond_probs = {}

            canonical_keys = set()
            for cond_key, probs in cond_probs.items():
                try:
                    cond_map = parse_condition(cond_key)
                except ValueError as exc:
                    warnings.append(
                        f"Column '{col_id}' has invalid condition key '{cond_key}': {exc}"
                    )
                    continue

                for k in cond_map:
                    if depend_on and k not in depend_on:
                        warnings.append(
                            f"Column '{col_id}' condition uses '{k}' not in depend_on"
                        )
                    if k not in column_set:
                        warnings.append(
                            f"Column '{col_id}' condition references unknown column '{k}'"
                        )

                if isinstance(probs, dict):
                    tp = probs.get("true_prob")
                    fp = probs.get("false_prob")
                    if tp is None or fp is None:
                        warnings.append(
                            f"Column '{col_id}' condition '{cond_key}' missing probabilities"
                        )
                    elif abs(tp + fp - 1.0) > 1e-6:
                        warnings.append(
                            f"Column '{col_id}' condition '{cond_key}' probabilities do not sum to 1"
                        )
                else:
                    warnings.append(
                        f"Column '{col_id}' condition '{cond_key}' has invalid probabilities"
                    )

                canonical_keys.add(canonical_condition_key(cond_map, depend_on or None))

            if depend_on:
                expected = set()
                for combo in itertools.product([0, 1], repeat=len(depend_on)):
                    expected.add(
                        ", ".join(f"{dep}={val}" for dep, val in zip(depend_on, combo))
                    )
                missing = sorted(expected - canonical_keys)
                if missing:
                    preview = ", ".join(missing[:5])
                    warnings.append(
                        f"Column '{col_id}' missing conditional cases (e.g., {preview})"
                    )

    if errors and strict:
        raise ValueError("; ".join(errors))
    if errors and not strict:
        raise ValueError("; ".join(errors))

    return warnings


def order_columns_by_dependency(config):
    columns = config.get("columns", [])
    id_to_col = {col.get("column_id"): col for col in columns if col.get("column_id")}
    deps = {}
    for col in columns:
        col_id = col.get("column_id")
        dist = col.get("distribution", {})
        if dist.get("type") == "conditional":
            depend_on = dist.get("depend_on", [])
            deps[col_id] = {dep for dep in depend_on if dep in id_to_col}
        else:
            deps[col_id] = set()

    incoming = {cid: set(deps.get(cid, set())) for cid in id_to_col}
    ready = [cid for cid, dep in incoming.items() if not dep]
    order = []
    while ready:
        cid = ready.pop(0)
        order.append(cid)
        for other, dep in incoming.items():
            if cid in dep:
                dep.remove(cid)
                if not dep and other not in order and other not in ready:
                    ready.append(other)

    if len(order) != len(id_to_col):
        return columns
    return [id_to_col[cid] for cid in order]


def _collect_references(config):
    referenced = set()
    sources = {}
    for col in config.get("columns", []):
        col_id = col.get("column_id")
        dist = col.get("distribution", {})
        if dist.get("type") != "conditional":
            continue
        depend_on = dist.get("depend_on", [])
        for dep in depend_on:
            referenced.add(dep)
            sources.setdefault(dep, set()).add(f"{col_id}:depend_on")
        cond_probs = dist.get("conditional_probs", {})
        if isinstance(cond_probs, dict):
            for cond_key in cond_probs.keys():
                try:
                    cond_map = parse_condition(cond_key)
                except ValueError:
                    continue
                for dep in cond_map.keys():
                    referenced.add(dep)
                    sources.setdefault(dep, set()).add(f"{col_id}:condition")
    return referenced, sources


def _add_missing_column(config, col_id, true_prob):
    entry = {
        "column_id": col_id,
        "values": {"true_value": 1, "false_value": 0},
        "distribution": {
            "type": "bernoulli",
            "probabilities": {
                "true_prob": float(true_prob),
                "false_prob": float(1.0 - float(true_prob)),
            },
        },
    }
    config.setdefault("columns", [])
    config["columns"].insert(0, entry)


def _remove_dependent_columns(config, missing_set):
    kept = []
    for col in config.get("columns", []):
        dist = col.get("distribution", {})
        if dist.get("type") != "conditional":
            kept.append(col)
            continue
        depend_on = set(dist.get("depend_on", []) or [])
        if depend_on & missing_set:
            continue
        cond_probs = dist.get("conditional_probs", {})
        if isinstance(cond_probs, dict):
            refs = set()
            for cond_key in cond_probs.keys():
                try:
                    cond_map = parse_condition(cond_key)
                except ValueError:
                    continue
                refs.update(cond_map.keys())
            if refs & missing_set:
                continue
        kept.append(col)
    config["columns"] = kept


def resolve_missing_columns(config, mode="prompt"):
    declared = {col.get("column_id") for col in config.get("columns", [])}
    referenced, sources = _collect_references(config)
    missing = sorted(referenced - declared)
    if not missing:
        return config

    if mode == "error":
        raise ValueError(f"Missing columns in config: {missing}")

    if mode == "skip":
        _remove_dependent_columns(config, set(missing))
        return config

    if mode != "prompt":
        raise ValueError("mode must be 'prompt', 'skip', or 'error'")

    if not sys.stdin.isatty():
        raise ValueError(
            f"Missing columns in config: {missing}. Run interactively to resolve."
        )

    pending = set(missing)
    while pending:
        col_id = sorted(pending)[0]
        src = ", ".join(sorted(sources.get(col_id, [])))
        print(f"[MISSING COLUMN] '{col_id}' referenced by: {src if src else 'unknown'}")
        print("Choose action:")
        print("  [1] Add column as bernoulli (ask for true_prob)")
        print("  [2] Drop dependent columns")
        print("  [3] Abort")
        choice = input("Selection (1/2/3): ").strip() or "3"
        if choice == "1":
            value = input("Enter true_prob [0.0-1.0, default 0.5]: ").strip()
            true_prob = 0.5
            if value:
                try:
                    true_prob = float(value)
                except ValueError:
                    print("Invalid number, using default 0.5")
                    true_prob = 0.5
            true_prob = max(0.0, min(1.0, true_prob))
            _add_missing_column(config, col_id, true_prob)
            declared.add(col_id)
        elif choice == "2":
            _remove_dependent_columns(config, {col_id})
        else:
            raise ValueError(f"Missing column '{col_id}' not resolved")

        referenced, sources = _collect_references(config)
        pending = set(referenced - declared)

    return config


def build_targets(config):
    marginal_targets = {}
    conditional_specs = {}
    column_set = {col.get("column_id") for col in config.get("columns", [])}

    for col in config["columns"]:
        col_id = col["column_id"]
        dist = col["distribution"]
        if dist["type"] == "bernoulli":
            marginal_targets[col_id] = float(dist["probabilities"]["true_prob"])
        elif dist["type"] == "conditional":
            depend_on = dist.get("depend_on", [])
            specs = []
            for cond_key, probs in (dist.get("conditional_probs") or {}).items():
                try:
                    cond_map = parse_condition(cond_key)
                except ValueError:
                    continue
                if any(k not in column_set for k in cond_map.keys()):
                    continue
                if not isinstance(probs, dict) or probs.get("true_prob") is None:
                    continue
                key = canonical_condition_key(cond_map, depend_on or None)
                specs.append(
                    {
                        "key": key,
                        "cond": cond_map,
                        "true_prob": float(probs["true_prob"]),
                    }
                )
            specs.sort(key=lambda s: s["key"])
            conditional_specs[col_id] = specs

    return marginal_targets, conditional_specs
